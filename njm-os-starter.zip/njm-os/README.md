# NJM OS — initial bootable prototype

NJM OS is a monochrome, macOS/Windows-inspired Linux desktop prototype intended for testing in UTM SE on iPad.

## What this starter does
- Uses Debian Live (Trixie) with XFCE as a lightweight, real desktop base.
- Includes a graphical login, file manager, terminal, Firefox ESR, networking and audio packages.
- Uses a GitHub Actions workflow to build an ISO in a cloud runner, so a Mac/PC is not required for the build step.

## Important limits
- This is an initial prototype, not a finished polished OS. The visual branding, custom dock/window behavior, settings integrations and compatibility testing are not complete.
- UTM SE on iPad uses emulation without JIT; performance can be slow, and the ISO must be tested on the user's exact UTM SE version/device.
- The workflow may need adjustments if Debian Live's package/build tooling changes or if the runner's permissions differ.

## Build from an iPad using GitHub
1. Create a GitHub repository named `njm-os` in Safari.
2. Upload the contents of this project ZIP to the repository (keep the `.github` folder).
3. Open the repository's **Actions** tab and enable workflows if prompted.
4. Run **Build NJM OS ISO** using **Run workflow** (or push to `main`).
5. When it completes, open the run, download the `njm-os-iso` artifact, and extract the `.iso` file from the downloaded ZIP.
6. In UTM SE, create a new VM and select the extracted ISO as its boot image. Start with a modest configuration (for example, 1 CPU core and 1–2 GB RAM if available), then adjust based on what UTM SE allows.

## Local build (optional)
On a Debian build machine with `live-build`, `debootstrap`, `xorriso` and `squashfs-tools` installed, run:

```sh
sudo ./build.sh
```

The resulting ISO should appear in the project/build directory (location depends on live-build version/configuration).
