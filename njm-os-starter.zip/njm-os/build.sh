#!/usr/bin/env bash
set -euo pipefail

# Run inside a Debian/Ubuntu build environment with live-build installed.
# This creates a bootable Debian Live ISO; it does not run on iPad locally.
lb config \
  --distribution trixie \
  --archive-areas "main contrib non-free non-free-firmware" \
  --binary-image iso-hybrid \
  --bootappend-live "boot=live components username=njm hostname=njm-os quiet splash" \
  --debian-installer false \
  --iso-application "NJM OS" \
  --iso-publisher "NJM OS Project" \
  --iso-volume "NJM_OS" \
  --linux-flavours amd64 \
  --system live

lb build
